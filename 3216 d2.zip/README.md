# TPA3116D2 4-Layer Class-D Audio Amplifier

This KiCad project is a **pre-fabrication reference layout** for a stereo BTL amplifier based on the TPA3116D2. The PCB measures 100 mm × 70 mm and is arranged from left to right: DC power entry and bulk capacitors, analog input/control, the power stage, then output filters and speaker connectors.

## Files

- `TPA3116D2_4Layer_ClassD.kicad_pcb` — editable 4-layer board layout.
- `TPA3116D2_4Layer_ClassD.sch` and `TPA3116D2_4Layer_ClassD-cache.lib` — editable legacy KiCad schematic and local custom amplifier symbol. KiCad will offer to migrate this schematic when it is first opened.
- `BOM.csv` — initial purchasing list.
- `FABRICATION_NOTES.md` — stackup, routing, DRC, and pre-release checklist.

## Layer stackup

| Layer | Intent |
|---|---|
| F.Cu | Components, short high-current paths, output routing |
| In1.Cu | Solid GND reference plane |
| In2.Cu | PVCC plane |
| B.Cu | Low-current routing and input return routing |

The board includes a 4 × 4 thermal-via field below the exposed pad and additional ground-stitching vias at the PCB perimeter. The top-side output filter locations are intentionally next to the speaker connectors to reduce the high-frequency switching loop area.

## Important release status

The supplied project is an editable starting design, **not a production release**. KiCad is not installed in this workspace, so I could not run ERC/DRC or generate verified Gerber/drill files. Before ordering, open the project in KiCad, update the schematic/footprints against the exact TPA3116D2 package and selected components, refill zones, run ERC/DRC, complete the output-filter and bootstrap networks, and generate manufacturing files from KiCad.

The power, output, and thermal choices must be reviewed by a qualified hardware engineer for the intended supply voltage, speaker impedance, enclosure, emissions requirements, and safety constraints.
