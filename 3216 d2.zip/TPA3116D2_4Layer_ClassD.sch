EESchema Schematic File Version 4
LIBS:TPA3116D2_4Layer_ClassD-cache
EELAYER 29 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title "4-Layer Class-D Audio Amplifier"
Date "2026-08-01"
Rev "0.1"
Comp "TPA3116D2 Stereo BTL • 12–24 VDC"
Comment1 "Pre-fabrication reference design: verify against selected package and TI datasheet."
Comment2 "Layer 2: solid GND plane; Layer 3: PVCC plane; keep LC output filters at connector edge."
Comment3 "Target: 2 × 35 W into 4 ohm, 21 V supply (thermal performance depends on enclosure)."
Comment4 ""
$EndDescr
Text Notes 7350 950 0 120 ~ 24
POWER ENTRY & BULK DECOUPLING
Text Notes 4550 950 0 120 ~ 24
TPA3116D2 STEREO BTL POWER STAGE
Text Notes 8750 4950 0 110 ~ 22
OUTPUT LC FILTERS
$Comp
L TPA3116D2 U1
U 1 1 66F01001
P 5800 4100
F 0 "U1" H 5800 5800 60  0000 C CNN
F 1 "TPA3116D2DAP" H 5800 5700 60 0000 C CNN
F 2 "Package_SO:HTSSOP-32-1EP_5x9.7mm_P0.5mm_EP3.45x5.2mm" H 5800 4100 50 0001 C CNN
F 3 "https://www.ti.com/lit/ds/symlink/tpa3116d2.pdf" H 5800 4100 50 0001 C CNN
	1    5800 4100
	1    0    0    -1
$EndComp
$Comp
L Connector_Generic:Conn_01x02 J1
U 1 1 66F01002
P 1650 1800
F 0 "J1" H 1568 2017 50 0000 C CNN
F 1 "DC_IN_12-24V" H 1568 1926 50 0000 C CNN
	1    1650 1800
	-1   0    0    -1
$EndComp
Wire Wire Line
	1850 1800 2500 1800
Wire Wire Line
	1850 1900 2500 1900
Text Label 2100 1800 0 50 ~ 0
+12V
Text Label 2100 1900 0 50 ~ 0
GND
$Comp
L Device:Fuse F1
U 1 1 66F01003
P 2900 1800
F 0 "F1" V 2703 1800 50 0000 C CNN
F 1 "5A PTC" V 2794 1800 50 0000 C CNN
	1    2900 1800
	0    1    1    0
$EndComp
Wire Wire Line
	2500 1800 2750 1800
Wire Wire Line
	3050 1800 3650 1800
Text Label 3200 1800 0 50 ~ 0
+PVCC
$Comp
L Device:D D1
U 1 1 66F01004
P 3900 2050
F 0 "D1" V 3854 2130 50 0000 L CNN
F 1 "SMBJ28A" V 3945 2130 50 0000 L CNN
	1    3900 2050
	0    1    1    0
$EndComp
Wire Wire Line
	3650 1800 3900 1800
Wire Wire Line
	3900 1800 3900 1900
Wire Wire Line
	3900 2200 3900 2350
Text Label 3900 2350 2 50 ~ 0
GND
$Comp
L Device:C_Polarized C1
U 1 1 66F01005
P 4550 2050
F 0 "C1" H 4668 2096 50 0000 L CNN
F 1 "470uF 35V" H 4668 2005 50 0000 L CNN
	1    4550 2050
	1    0    0    -1
$EndComp
$Comp
L Device:C_Polarized C2
U 1 1 66F01006
P 5200 2050
F 0 "C2" H 5318 2096 50 0000 L CNN
F 1 "470uF 35V" H 5318 2005 50 0000 L CNN
	1    5200 2050
	1    0    0    -1
$EndComp
Wire Wire Line
	3900 1800 4550 1800
Wire Wire Line
	4550 1800 4550 1900
Wire Wire Line
	4550 1800 5200 1800
Wire Wire Line
	5200 1800 5200 1900
Wire Wire Line
	4550 2200 4550 2350
Wire Wire Line
	4550 2350 5200 2350
Wire Wire Line
	5200 2350 5200 2200
Text Label 5200 2350 2 50 ~ 0
GND
Text Label 4750 1800 0 50 ~ 0
+PVCC
$Comp
L Connector_Generic:Conn_01x03 J2
U 1 1 66F01007
P 1700 4300
F 0 "J2" H 1618 4617 50 0000 C CNN
F 1 "AUDIO_IN" H 1618 4526 50 0000 C CNN
	1    1700 4300
	-1   0    0    -1
$EndComp
Wire Wire Line
	1900 4200 2550 4200
Wire Wire Line
	1900 4300 2550 4300
Wire Wire Line
	1900 4400 2550 4400
Text Label 2150 4200 0 50 ~ 0
L_IN
Text Label 2150 4300 0 50 ~ 0
AGND
Text Label 2150 4400 0 50 ~ 0
R_IN
$Comp
L Device:R R1
U 1 1 66F01008
P 3150 4200
F 0 "R1" V 2943 4200 50 0000 C CNN
F 1 "20k" V 3034 4200 50 0000 C CNN
	1    3150 4200
	0    1    1    0
$EndComp
$Comp
L Device:R R2
U 1 1 66F01009
P 3150 4400
F 0 "R2" V 2943 4400 50 0000 C CNN
F 1 "20k" V 3034 4400 50 0000 C CNN
	1    3150 4400
	0    1    1    0
$EndComp
Wire Wire Line
	2550 4200 3000 4200
Wire Wire Line
	2550 4400 3000 4400
Wire Wire Line
	3300 4200 4000 4200
Wire Wire Line
	3300 4400 4000 4400
Text Label 3650 4200 0 50 ~ 0
L_IN
Text Label 3650 4400 0 50 ~ 0
R_IN
Wire Wire Line
	5100 4400 4000 4400
Wire Wire Line
	5100 4250 4000 4250
Text Label 4250 4250 0 50 ~ 0
L_IN
Text Label 4250 4400 0 50 ~ 0
R_IN
Text Label 4950 5500 2 50 ~ 0
GND
Wire Wire Line
	5100 4950 4650 4950
Text Label 4650 4950 0 50 ~ 0
GND
Wire Wire Line
	5100 5100 4650 5100
Text Label 4650 5100 0 50 ~ 0
+PVCC
Wire Wire Line
	5100 5300 4650 5300
Text Label 4650 5300 0 50 ~ 0
MUTE
Wire Wire Line
	5100 5500 4650 5500
Text Label 4650 5500 0 50 ~ 0
SDZ
Wire Wire Line
	6500 3800 7150 3800
Wire Wire Line
	6500 4350 7150 4350
Wire Wire Line
	6500 4500 7150 4500
Wire Wire Line
	6500 5250 7150 5250
Text Label 6800 3800 0 50 ~ 0
OUTPL
Text Label 6800 4350 0 50 ~ 0
OUTNL
Text Label 6800 4500 0 50 ~ 0
OUTPR
Text Label 6800 5250 0 50 ~ 0
OUTNR
$Comp
L Device:L L1
U 1 1 66F01010
P 8100 3800
F 0 "L1" V 8290 3800 50 0000 C CNN
F 1 "10uH 8A" V 8199 3800 50 0000 C CNN
	1    8100 3800
	0    -1   -1   0
$EndComp
$Comp
L Device:L L2
U 1 1 66F01011
P 8100 4350
F 0 "L2" V 8290 4350 50 0000 C CNN
F 1 "10uH 8A" V 8199 4350 50 0000 C CNN
	1    8100 4350
	0    -1   -1   0
$EndComp
$Comp
L Device:L L3
U 1 1 66F01012
P 8100 4500
F 0 "L3" V 8290 4500 50 0000 C CNN
F 1 "10uH 8A" V 8199 4500 50 0000 C CNN
	1    8100 4500
	0    -1   -1   0
$EndComp
$Comp
L Device:L L4
U 1 1 66F01013
P 8100 5250
F 0 "L4" V 8290 5250 50 0000 C CNN
F 1 "10uH 8A" V 8199 5250 50 0000 C CNN
	1    8100 5250
	0    -1   -1   0
$EndComp
Wire Wire Line
	7150 3800 7950 3800
Wire Wire Line
	7150 4350 7950 4350
Wire Wire Line
	7150 4500 7950 4500
Wire Wire Line
	7150 5250 7950 5250
Wire Wire Line
	8250 3800 8900 3800
Wire Wire Line
	8250 4350 8900 4350
Wire Wire Line
	8250 4500 8900 4500
Wire Wire Line
	8250 5250 8900 5250
$Comp
L Connector_Generic:Conn_01x02 J3
U 1 1 66F01014
P 9150 3900
F 0 "J3" H 9230 3892 50 0000 L CNN
F 1 "SPEAKER_L" H 9230 3801 50 0000 L CNN
	1    9150 3900
	1    0    0    -1
$EndComp
Wire Wire Line
	8900 3800 8900 3900
Wire Wire Line
	8900 3900 8950 3900
Wire Wire Line
	8900 4350 8900 4000
Wire Wire Line
	8900 4000 8950 4000
$Comp
L Connector_Generic:Conn_01x02 J4
U 1 1 66F01015
P 9150 5000
F 0 "J4" H 9230 4992 50 0000 L CNN
F 1 "SPEAKER_R" H 9230 4901 50 0000 L CNN
	1    9150 5000
	1    0    0    -1
$EndComp
Wire Wire Line
	8900 4500 8900 5000
Wire Wire Line
	8900 5000 8950 5000
Wire Wire Line
	8900 5250 8900 5100
Wire Wire Line
	8900 5100 8950 5100
Text Notes 7600 5800 0 70 ~ 14
Use 10uH shielded inductors rated ≥8A.\nConfirm LC values and EMI network with chosen supply, speaker load and enclosure.
Text Notes 1100 6850 0 70 ~ 14
Design intent:\n• Wide top-layer PVCC and output routing; no signal traces under the output inductors.\n• In1.Cu is an uninterrupted ground plane. In2.Cu is a PVCC plane.\n• Thermal pad uses a 4 × 4 stitched-via array to the ground plane.\n• Review all component ratings, creepage/clearance, DRC and thermal behavior before release.
$EndSCHEMATC
