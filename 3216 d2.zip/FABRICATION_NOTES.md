# Fabrication and design-review notes

## Board and stackup

- Board outline: 100 mm × 70 mm, nominal 1.6 mm FR-4, ENIG finish.
- Copper: 1 oz outer layers and 1 oz internal layers minimum. Confirm final impedance/stackup with the chosen fabricator.
- Stackup: F.Cu signal/high-current; In1 solid GND; In2 PVCC; B.Cu signal.
- Keep In1.Cu unbroken beneath the amplifier, local bypass capacitors, and the analog input region. Do not route the switching-output nets on In1.Cu.

## Routing constraints

- PVCC main path and speaker output paths: 1.5 mm minimum external trace width; keep these short and direct.
- Control/input traces: 0.25 mm nominal; route away from OUTPx/OUTNx, inductors, and the speaker connectors.
- Maintain at least 0.35 mm copper clearance around switching-output nets and use the selected PCB house’s larger requirement if applicable.
- Keep bootstrap capacitors and local PVCC ceramics immediately at their assigned IC pins in the completed schematic/layout.
- Retain the 4 × 4 exposed-pad thermal-via array. Tent or plug vias if solder wicking is a concern; confirm with assembly house.

## Mandatory pre-release checklist

1. Replace the reference symbol with the exact TPA3116D2 datasheet symbol/pin mapping and reconcile PCB pads from schematic.
2. Add and verify the four bootstrap capacitors, input coupling/filter networks, and any required ferrite/EMI components for the final use case.
3. Select actual manufacturer part numbers and validate voltage, current, dissipation, ESR/DCR, footprint, and availability.
4. In KiCad, refill all zones, run ERC and DRC with the selected fabricator rules, and resolve every intentional versus accidental violation.
5. Review the BTL outputs: neither speaker terminal may be connected to chassis/analog ground.
6. Perform a thermal review and bench test with current-limited supply, dummy loads, and an oscilloscope before connecting speakers.
7. Generate Gerbers, drill files, pick-and-place, assembly drawings, and final BOM from the verified KiCad project.
